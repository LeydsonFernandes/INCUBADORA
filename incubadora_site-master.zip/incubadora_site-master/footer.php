 <!-- Footer -->

  <footer class="bg-light py-5">
    <div class="container">
      <div class="texto-rodape">Copyright &copy; 2019 - Start Bootstrap</div>
    </div>
  </footer>
 <?php wp_footer(); ?>
  <!-- Bootstrap core JavaScript -->
  <script src="<?php bloginfo('template_url')?>/assets/vendor/jquery/jquery.min.js"></script>
  <script src="<?php bloginfo('template_url')?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="<?php bloginfo('template_url')?>/assets/vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="<?php bloginfo('template_url')?>/assets/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

  <!-- Custom scripts for this template -->
  <script src="<?php bloginfo('template_url')?>/assets/js/creative.min.js"></script>

</body>

</html>